<!-- Menu Plugin JavaScript -->
<script src="<?php echo $public_prefix; ?>/dependencies/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
<!--slimscroll JavaScript -->
<script src="<?php echo $public_prefix; ?>/dependencies/assets/js/jquery.slimscroll.js"></script>
<!--Morris JavaScript -->
<script src="<?php echo $public_prefix; ?>/dependencies/plugins/bower_components/raphael/raphael-min.js"></script>
<script src="<?php echo $public_prefix; ?>/dependencies/plugins/bower_components/morrisjs/morris.js"></script>
<!-- Sparkline chart JavaScript -->
<script src="<?php echo $public_prefix; ?>/dependencies/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
<!-- jQuery peity -->
<script src="<?php echo $public_prefix; ?>/dependencies/plugins/bower_components/peity/jquery.peity.min.js"></script>
<script src="<?php echo $public_prefix; ?>/dependencies/plugins/bower_components/peity/jquery.peity.init.js"></script>
<!--Wave Effects -->
<script src="<?php echo $public_prefix; ?>/dependencies/assets/js/waves.js"></script>
<!-- Custom Theme JavaScript -->
<script src="<?php echo $public_prefix; ?>/dependencies/assets/js/custom.min.js"></script>
<script src="<?php echo $public_prefix; ?>/dependencies/assets/js/dashboard1.js"></script>
<!--Style Switcher -->
<script src="<?php echo $public_prefix; ?>/dependencies/plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
